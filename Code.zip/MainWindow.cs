using Gtk;
using GtkSource;
using System;
using System.IO;
using UI = Gtk.Builder.ObjectAttribute;
using System.Collections.Generic;

namespace Note_Taking_App2
{
    internal class MainWindow : Window
    {
        [UI] private Notebook notebook1 = null;
        private CssProvider textviewCssProvider = new CssProvider();
        private CssProvider provider = new CssProvider();  
        private uint scale = 100;
        private readonly Dictionary <Button, Editor> editor_buttons = new Dictionary<Button, Editor>();
        public MainWindow() : this(new Builder("MainWindow.glade")) { }

        private MainWindow(Builder builder) : base(builder.GetRawOwnedObject("MainWindow")) // CONSTRUCTOR
        {
            builder.Autoconnect(this); // connects signals to appropriate widgets (magic)

            provider.LoadFromPath("gtk.css");
            Gtk.StyleContext.AddProviderForScreen(Gdk.Screen.Default, provider, 800);
            
            //notebook1.StyleContext.AddClass("launcher_box");

            // Post initialization code
            update_zoom_level(); // Calling A Method
            on_new_activate(null, null); // Initial Tab
        }
        
        private void update_zoom_level()
        {
            var pt = Math.Round(18.0 * scale / 100);
            textviewCssProvider.LoadFromData($"textview {{ font-family: Consolas, Inconsolata, monospace; font-size: {pt}pt; }}");
        }

        private void on_new_activate(object sender, EventArgs a)
        {
            var label = new Label("Untitled Document");
            var editor = new Editor(textviewCssProvider, label, this);
            var box = new Box(Orientation.Horizontal, 0);

            box.PackStart(label, true, false, 0);
            label.Show();
            var button = new Button("\ud83d\udfae");
            button.Relief = ReliefStyle.None;
            editor_buttons.Add(button, editor);
            button.Clicked += on_close_activated;
            box.PackStart(button, false, false, 0);
            button.Show();
            box.Hexpand = true;
            
            var idx = notebook1.AppendPage(editor, box);
            notebook1.CurrentPage = idx;

        }

        private void on_close_activated(object sender, EventArgs a)
        { 
            var button = (Button)sender;
            var editor = editor_buttons[button];
            var pagenum = notebook1.PageNum(editor);

            if (editor.is_buffer_dirty())
            {
                var messagebox = new MessageDialog
                    (this, DialogFlags.Modal, MessageType.Question, ButtonsType.YesNo, 
                    "Save Changes To Document \"{0}\" Before Closing?", editor.get_file_name());

                var response = (ResponseType)messagebox.Run();
                messagebox.Destroy();

                switch (response)
                {
                    case ResponseType.Yes:
                        on_save_activate(null, null);
                        return;

                    case ResponseType.No:
                        break;
                        
                    case ResponseType.DeleteEvent:
                        return;
                }
            }

            notebook1.RemovePage(pagenum);

            editor_buttons.Remove(button);
        }
          
        private void on_revert_activate(object sender, EventArgs a)
        {
            get_current_editor().revert();
        }


        private void on_open_activate(object sender, EventArgs a)
        {
            on_new_activate(null, null);
            var dialog = new Gtk.FileChooserDialog("Open", this, FileChooserAction.Open, new object[] { "Cancel", ResponseType.Cancel, "Open", ResponseType.Accept });
            var res = dialog.Run();
            if (res == (int)ResponseType.Accept)
            {
                var editor = get_current_editor();
                editor.open_file(dialog.Filename);
            }
            dialog.Destroy();
        }

        private void on_notebook1_switch_page(object sender, SwitchPageArgs a)
        {
            get_current_editor().update_title();
        }

        public Editor get_current_editor()
        {
            var total = notebook1.NPages;
            var pagenumber = notebook1.CurrentPage;
            
            var page = notebook1.GetNthPage(pagenumber);
            notebook1.ShowTabs = false;
            if (total > 1)
            {
                notebook1.ShowTabs = true;
            }
            return (Editor)page; // Cast
        }


        private void on_save_activate(object sender, EventArgs a)
        {
            var editor = get_current_editor();
            if (editor.has_save_name())
            {
                editor.save_file();
            }
            else
            {
                on_save_as_activate(sender, a);
            }
        }

        private void on_save_as_activate(object sender, EventArgs a)
        {
            var dialog = new Gtk.FileChooserDialog("Save As", this, FileChooserAction.Save, new object[] { "Cancel", ResponseType.Cancel, "Save", ResponseType.Accept });
            dialog.DoOverwriteConfirmation = true;
            var res = dialog.Run();
            if (res == (int)ResponseType.Accept)
            {
                Editor editor = get_current_editor();
                editor.save_file(dialog.Filename);
            }
            dialog.Destroy();
        }
        
        private void on_zoom_in_activate(object sender, EventArgs a)
        {
            if (scale < 500)
                scale += 10; // Incrementing Scale + 10%
            update_zoom_level(); // Calling to a method
        }
        
        private void on_zoom_out_activate(object sender, EventArgs a)
        {
            if (scale > 10)
                scale -= 10; // Incrementing Scale + 10%
            update_zoom_level();
        }

        private void on_restore_default_zoom_activate(object sender, EventArgs a)
        {
            scale = 100;
            update_zoom_level();
        }

        private void on_quit_activate(object sender, EventArgs a)
        {
            Application.Quit();
        }

        private void Window_DeleteEvent(object sender, DeleteEventArgs a)
        {
            Application.Quit();
        }
    }
}
