﻿using System;
using System.IO;
using Gtk;
using GtkSource;
using UI = Gtk.Builder.ObjectAttribute;

namespace Note_Taking_App2
{
    internal class Editor : ScrolledWindow
    {
        [UI] private SourceView sourceview1 = null;
        private string currentFileName = null;
        private bool bufferdirty = false;
        public Label label;
        public MainWindow window;

        public Editor(CssProvider sourceviewCssProvider, Label label, MainWindow window) 
            : this(new Builder("Editor.glade"), sourceviewCssProvider, label, window) { }

        private Editor(Builder builder, CssProvider sourceviewCssProvider, Label label, MainWindow window) 
            : base(builder.GetRawOwnedObject("editor")) // CONSTRUCTOR
        {
            this.label = label;
            this.window = window;
            builder.Autoconnect(this); // connects signals to appropriate widgets (magic)
            sourceview1.StyleContext.AddProvider(sourceviewCssProvider, StyleProviderPriority.Application);

            var styleman = new StyleSchemeManager();
            styleman.SetProperty("search-path", new GLib.Value(new string[] { "SourceView" }));
            sourceview1.Buffer.StyleScheme = styleman.GetScheme("classic");
            var langman = new LanguageManager(); // This is how to call an Object!!
            langman.SetProperty("search-path", new GLib.Value(new string[] { "SourceView" }));
            sourceview1.Buffer.Language = langman.GetLanguage("markdown");

            sourceview1.Buffer.Changed += on_buffer_changed;

            // Post initialization code
        }
        
        public void update_title()
        {
            window.Title = label.Text;

        }

        public void revert()
        { 
            if (currentFileName == null)
            {
                return;
            }
            open_file(currentFileName);
        }

        private void set_current_file(string path)
        {
            currentFileName = path;
            label.Text = System.IO.Path.GetFileName(path);
            if (this == window.get_current_editor())
            {
                update_title();
                
            }
        }

        private void on_buffer_changed(object sender, EventArgs a)
        {
            bufferdirty = true;
        }

        public void open_file(string path)
        {
            sourceview1.Buffer.Text = System.IO.File.ReadAllText(path).Replace("\r\n", "\n");
            set_current_file(path);
            bufferdirty = false;
        }
        
        public void save_file(string file)
        {
            System.IO.File.WriteAllText(file, sourceview1.Buffer.Text);
            set_current_file(file);
            bufferdirty = false;
        }
    
        public bool has_save_name()
        {
            return currentFileName != null;
        }
    
        public void save_file()
        {
            System.IO.File.WriteAllText(currentFileName, sourceview1.Buffer.Text);
            bufferdirty = false;
        }

        public bool is_buffer_dirty()
        {
            return bufferdirty;
        }

        public string get_file_name()
        {
            if (currentFileName != null)
                return currentFileName;
            return "Untitled";

        }
    }
}
